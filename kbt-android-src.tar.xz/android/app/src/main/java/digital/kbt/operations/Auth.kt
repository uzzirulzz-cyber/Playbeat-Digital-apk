package digital.kbt.operations

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import java.security.MessageDigest
import java.security.SecureRandom
import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Generic PKCE bridge for a user-controlled, OAuth-enabled gateway.
 * Gateway must implement GET /v1/auth/authorize and POST /v1/auth/token.
 * This does NOT imitate OpenAI OAuth or claim Sign in with ChatGPT approval.
 */
object AuthFlow {
  const val CALLBACK="kbtops://auth/callback"
  private fun urlEnc(x:String)=URLEncoder.encode(x,"UTF-8")
  fun launch(activity:Activity, vm:OpsViewModel, provider:String="workspace") {
    if(vm.gatewayUrl.isBlank()){vm.toast="Set up your secure gateway in Settings first";return}
    val bytes=ByteArray(32).also{SecureRandom().nextBytes(it)}
    val verifier=Base64.encodeToString(bytes,Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
    val challenge=Base64.encodeToString(MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray()),Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
    val state=Base64.encodeToString(ByteArray(24).also{SecureRandom().nextBytes(it)},Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
    activity.getSharedPreferences("kbt_auth_pending",0).edit().putString("state",state).putString("verifier",verifier).putString("provider",provider).apply()
    val url="${vm.gatewayUrl}/v1/auth/authorize?provider=${urlEnc(provider)}&client_id=kbt-android&redirect_uri=${urlEnc(CALLBACK)}&response_type=code&code_challenge_method=S256&code_challenge=${urlEnc(challenge)}&state=${urlEnc(state)}"
    activity.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE))
  }
}
class AuthCallbackActivity:Activity() {
  override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState)
    val uri=intent?.data
    val prefs=getSharedPreferences("kbt_auth_pending",0)
    val state=prefs.getString("state",null)
    val ok=state!=null && state==uri?.getQueryParameter("state")
    val code=uri?.getQueryParameter("code")
    val gateway=getSharedPreferences("kbt_local_workspace_v1",0).getString("gateway","") ?: ""
    val verifier=prefs.getString("verifier","") ?: ""
    val provider=prefs.getString("provider","") ?: ""
    prefs.edit().clear().apply()
    if(ok && !code.isNullOrBlank() && gateway.startsWith("https://") && verifier.isNotBlank()) {
      Thread {
        try {
          val endpoint=URL("$gateway/v1/auth/token")
          val c=endpoint.openConnection() as HttpURLConnection
          c.requestMethod="POST";c.connectTimeout=12000;c.readTimeout=12000;c.doOutput=true
          c.setRequestProperty("Content-Type","application/json")
          val body=JSONObject().put("grant_type","authorization_code").put("code",code).put("code_verifier",verifier)
            .put("redirect_uri",AuthFlow.CALLBACK).put("client_id","kbt-android").put("provider",provider)
          c.outputStream.use{it.write(body.toString().toByteArray())}
          if(c.responseCode in 200..299){
            val data=JSONObject(c.inputStream.bufferedReader().use{it.readText()})
            val access=data.optString("access_token")
            if(access.isNotBlank()){Vault(this).putToken(access);getSharedPreferences("kbt_auth_result",0).edit().putString("result","Connected to $provider").apply()}
          }else getSharedPreferences("kbt_auth_result",0).edit().putString("result","Authorization was not completed ($provider)").apply()
          c.disconnect()
        }catch(_:Exception){getSharedPreferences("kbt_auth_result",0).edit().putString("result","Secure gateway could not complete authorization").apply()}
        runOnUiThread {startActivity(Intent(this,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP));finish()}
      }.start()
    } else { startActivity(Intent(this,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP));finish() }
  }
}

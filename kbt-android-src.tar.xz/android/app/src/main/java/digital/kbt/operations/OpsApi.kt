package digital.kbt.operations

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** All provider secrets and database credentials stay on server. */
class OpsApi(private val vm:OpsViewModel) {
  private fun call(method:String,path:String,body:JSONObject?=null):Pair<Int,String> {
    val token=vm.vault.readToken() ?: return 401 to "Sign in to your operations gateway first"
    if(!vm.gatewayUrl.startsWith("https://")) return 400 to "Secure HTTPS operations gateway required"
    val c=URL(vm.gatewayUrl+path).openConnection() as HttpURLConnection
    c.requestMethod=method;c.connectTimeout=12000;c.readTimeout=20000
    c.setRequestProperty("Authorization","Bearer $token")
    c.setRequestProperty("Accept","application/json")
    if(body!=null){c.doOutput=true;c.setRequestProperty("Content-Type","application/json");c.outputStream.use{it.write(body.toString().toByteArray())}}
    return try { val status=c.responseCode;val data=(if(status in 200..299)c.inputStream else c.errorStream)?.bufferedReader()?.use{it.readText()} ?: ""
      status to data
    } finally {c.disconnect()}
  }
  fun ask(prompt:String):String {
    val (code,body)=call("POST","/v1/codex/messages",JSONObject().put("message",prompt))
    if(code !in 200..299) throw IllegalStateException("Agent request failed (HTTP $code): ${body.take(140)}")
    return JSONObject(body).optString("reply").ifBlank{"The gateway returned no reply."}
  }
  fun status(worker:Worker):String {
    if(worker.endpoint.isBlank())return "Not connected"
    val (code,body)=call("GET","/v1/workers/${java.net.URLEncoder.encode(worker.id,"UTF-8")}/status")
    return if(code in 200..299) JSONObject(body).optString("status","Unknown") else "Unavailable (HTTP $code)"
  }
  fun authorizeConnector(id:String):Boolean {
    val (code,response)=call("GET","/v1/connectors/${java.net.URLEncoder.encode(id,"UTF-8")}/status")
    return code in 200..299 && JSONObject(response).optBoolean("connected",false)
  }
}

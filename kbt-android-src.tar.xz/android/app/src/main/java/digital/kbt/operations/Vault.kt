package digital.kbt.operations

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Access tokens are stored locally only with Android KeyStore AES/GCM. Never store DB credentials. */
class Vault(context:Context) {
  private val prefs=context.getSharedPreferences("kbt_secure_session",Context.MODE_PRIVATE)
  private val alias="digital.kbt.operations.session.v1"
  private fun key():SecretKey {
    val ks=KeyStore.getInstance("AndroidKeyStore").apply{load(null)}
    (ks.getKey(alias,null) as? SecretKey)?.let{return it}
    return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore").apply{
      init(KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
        .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
        .setUserAuthenticationRequired(false).build())
    }.generateKey()
  }
  fun putToken(s:String){
    val cipher=Cipher.getInstance("AES/GCM/NoPadding").apply{init(Cipher.ENCRYPT_MODE,key())}
    prefs.edit().putString("iv", Base64.encodeToString(cipher.iv,Base64.NO_WRAP))
      .putString("token",Base64.encodeToString(cipher.doFinal(s.toByteArray()),Base64.NO_WRAP)).apply()
  }
  fun readToken():String? { return try {
    val iv=Base64.decode(prefs.getString("iv",null) ?: return null,Base64.NO_WRAP)
    val value=Base64.decode(prefs.getString("token",null) ?: return null,Base64.NO_WRAP)
    Cipher.getInstance("AES/GCM/NoPadding").apply{init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,iv))}
      .doFinal(value).toString(Charsets.UTF_8)
  }catch(_:Exception){clear();null} }
  fun clear(){prefs.edit().clear().apply()}
}

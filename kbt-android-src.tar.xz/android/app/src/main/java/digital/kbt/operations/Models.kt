package digital.kbt.operations

import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.UUID

data class Project(val id: String = UUID.randomUUID().toString(), val name: String, val details: String, val status: String = "Active", val created: String = LocalDate.now().toString()) {
    fun toJson() = JSONObject().put("id", id).put("name", name).put("details", details).put("status", status).put("created", created)
    companion object { fun from(o: JSONObject) = Project(o.optString("id"), o.optString("name"), o.optString("details"), o.optString("status", "Active"), o.optString("created")) }
}
data class OpsTask(val id: String = UUID.randomUUID().toString(), val title: String, val projectId: String = "", val due: String = LocalDate.now().toString(), val priority: String = "Normal", val done: Boolean = false) {
    fun toJson() = JSONObject().put("id", id).put("title", title).put("projectId", projectId).put("due", due).put("priority", priority).put("done", done)
    companion object { fun from(o: JSONObject) = OpsTask(o.optString("id"), o.optString("title"), o.optString("projectId"), o.optString("due"), o.optString("priority", "Normal"), o.optBoolean("done")) }
}
data class Worker(val id: String = UUID.randomUUID().toString(), val name: String, val role: String, val endpoint: String = "", val lastStatus: String = "Not connected") {
    fun toJson() = JSONObject().put("id", id).put("name", name).put("role", role).put("endpoint", endpoint).put("lastStatus", lastStatus)
    companion object { fun from(o: JSONObject) = Worker(o.optString("id"), o.optString("name"), o.optString("role"), o.optString("endpoint"), o.optString("lastStatus", "Not connected")) }
}
data class Meeting(val id: String = UUID.randomUUID().toString(), val title: String, val date: String, val notes: String = "") {
    fun toJson() = JSONObject().put("id", id).put("title", title).put("date", date).put("notes", notes)
    companion object { fun from(o: JSONObject) = Meeting(o.optString("id"), o.optString("title"), o.optString("date"), o.optString("notes")) }
}
data class ChatEntry(val role: String, val content: String, val at: String = java.time.Instant.now().toString()) {
    fun toJson() = JSONObject().put("role", role).put("content", content).put("at", at)
    companion object { fun from(o: JSONObject) = ChatEntry(o.optString("role"), o.optString("content"), o.optString("at")) }
}
data class Connection(val id: String, val title: String, val category: String, val sub: String, val auth: String = "oauth")
val connectionCatalog = listOf(
    Connection("codex", "ChatGPT / Codex", "AI Workspace", "Sign in with ChatGPT requires an approved app registration"),
    Connection("gmail", "Gmail", "Google", "Mail, drafting and label management"),
    Connection("calendar", "Google Calendar", "Google", "Meetings and calendar sync"),
    Connection("drive", "Google Drive", "Google", "Project docs and shared files"),
    Connection("dropbox", "Dropbox", "Files", "Cloud files and deliverables"),
    Connection("github", "GitHub", "Engineering", "Repos, issues, workflows and pull requests"),
    Connection("vercel", "Vercel", "Infrastructure", "Deployments, projects and logs"),
    Connection("cloudflare", "Cloudflare", "Infrastructure", "Workers, routes, zones and deployments"),
    Connection("neon", "Neon PostgreSQL", "Database", "Server-side database connection", "server"),
    Connection("mongodb", "MongoDB Atlas", "Database", "Server-side database connection", "server"),
    Connection("facebook", "Facebook Pages", "Meta", "Pages, comments and messaging"),
    Connection("instagram", "Instagram Business", "Meta", "Publishing, insights and inbox")
)
fun <T> parseRecords(raw: String?, block: (JSONObject) -> T): List<T> = try {
    val list = JSONArray(raw ?: "[]")
    (0 until list.length()).map { block(list.getJSONObject(it)) }
} catch (_: Exception) { emptyList() }
fun <T> serializeRecords(records: List<T>, block: (T) -> JSONObject): String = JSONArray().apply { records.forEach { put(block(it)) } }.toString()

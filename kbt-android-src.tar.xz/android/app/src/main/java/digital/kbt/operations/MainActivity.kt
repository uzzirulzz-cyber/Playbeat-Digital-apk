package digital.kbt.operations

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.concurrent.thread

private val Bg=Color(0xFF090D19)
private val Surface=Color(0xFF141E32)
private val Surface2=Color(0xFF1B2A42)
private val Sky=Color(0xFF69C6F5)
private val Gold=Color(0xFFFBC253)
private val Muted=Color(0xFF99A9BE)
private val Mint=Color(0xFF8AE0BF)
private val Rose=Color(0xFFFB879C)

class MainActivity:ComponentActivity() {
 override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState);enableEdgeToEdge();setContent {
   val vm:OpsViewModel=viewModel()
   MaterialTheme(colorScheme=darkColorScheme(primary=Sky,onPrimary=Bg,background=Bg,onBackground=Color.White,surface=Surface,onSurface=Color.White,secondary=Gold)) {
     OperationsRoot(vm)
   }
 } }
 override fun onNewIntent(intent:Intent){super.onNewIntent(intent);setIntent(intent)}
}

private data class NavTab(val id:String,val name:String,val icon:ImageVector)
private val tabs=listOf(
    NavTab("home","Home",Icons.Default.SpaceDashboard),
    NavTab("codex","Codex",Icons.Default.AutoAwesome),
    NavTab("projects","Work",Icons.Default.FolderOpen),
    NavTab("calendar","Calendar",Icons.Default.CalendarMonth),
    NavTab("workers","Workers",Icons.Default.SmartToy),
    NavTab("connectors","Connect",Icons.Default.Hub)
)
@Composable fun OperationsRoot(vm:OpsViewModel) {
 var screen by remember { mutableStateOf("home") }
 val context=LocalContext.current
 LifecycleEventEffect(Lifecycle.Event.ON_RESUME){ vm.sessionValid=vm.vault.readToken()!=null }
 LaunchedEffect(Unit) {
    val pref=context.getSharedPreferences("kbt_auth_result",0)
    val message=pref.getString("result",null)
    if(message!=null){vm.toast=message;vm.sessionValid=vm.vault.readToken()!=null;pref.edit().clear().apply()}
 }
 LaunchedEffect(vm.toast) { if(vm.toast.isNotEmpty()) { /* user can dismiss alert */ } }
 Scaffold(containerColor=Bg,topBar={
    Row(Modifier.fillMaxWidth().background(Bg).statusBarsPadding().padding(horizontal=18.dp,vertical=11.dp),verticalAlignment=Alignment.CenterVertically){
       Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(Brush.linearGradient(listOf(Gold,Sky))),contentAlignment=Alignment.Center){Text("K",fontSize=23.sp,fontWeight=FontWeight.Black,color=Bg)}
       Spacer(Modifier.width(10.dp))
       Column(Modifier.weight(1f)){Text("KBT OPERATIONS",fontWeight=FontWeight.ExtraBold,fontSize=16.sp,letterSpacing=1.sp);Text("COMMAND CENTER",fontSize=10.sp,color=Muted,letterSpacing=2.sp)}
       Box(Modifier.size(8.dp).clip(CircleShape).background(if(vm.sessionValid)Mint else Gold))
       Spacer(Modifier.width(7.dp))
       Text(if(vm.sessionValid)"ONLINE" else "LOCAL",color=if(vm.sessionValid)Mint else Gold,fontSize=10.sp,fontWeight=FontWeight.Bold)
       IconButton(onClick={screen="settings"}){Icon(Icons.Default.Settings,"Settings",tint=Muted)}
    }
 },bottomBar={
   if(screen!="settings"){
     NavigationBar(containerColor=Color(0xFF10192B),contentColor=Color.White,tonalElevation=3.dp,modifier=Modifier.navigationBarsPadding()) {
       tabs.forEach { tab -> NavigationBarItem(selected=screen==tab.id,onClick={screen=tab.id},alwaysShowLabel=false,
        icon={Icon(tab.icon,tab.name,modifier=Modifier.size(22.dp))},label={Text(tab.name,fontSize=9.sp)},
        colors=NavigationBarItemDefaults.colors(selectedIconColor=Gold,selectedTextColor=Gold,indicatorColor=Surface2,unselectedIconColor=Muted,unselectedTextColor=Muted)) }
     }
   }
 }) { padding ->
   Box(Modifier.fillMaxSize().padding(padding).background(Brush.verticalGradient(listOf(Bg,Color(0xFF0B1525),Bg)))) {
      when(screen){
       "home"->HomePage(vm,onNavigate={screen=it})
       "codex"->ChatPage(vm)
       "projects"->ProjectsPage(vm)
       "calendar"->CalendarPage(vm)
       "workers"->WorkersPage(vm)
       "connectors"->ConnectorsPage(vm)
       "settings"->SettingsPage(vm,onBack={screen="home"})
      }
      if(vm.toast.isNotBlank()) SurfaceNotice(vm.toast,Modifier.align(Alignment.BottomCenter)){vm.toast=""}
   }
 }
}

@Composable private fun SurfaceNotice(message:String, modifier:Modifier=Modifier,onDismiss:()->Unit){
 Surface(modifier.padding(14.dp).clickable(onClick=onDismiss),color=Surface2,shadowElevation=12.dp,shape=RoundedCornerShape(14.dp)) {
  Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Info,"Information",tint=Gold);Spacer(Modifier.width(8.dp));Text(message,Modifier.weight(1f),fontSize=12.sp);Icon(Icons.Default.Close,"Dismiss",Modifier.size(18.dp))}
 }
}
@Composable private fun Header(title:String,sub:String?=null,trailing:(@Composable ()->Unit)?=null){
 Row(Modifier.fillMaxWidth().padding(bottom=18.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(title,fontSize=26.sp,fontWeight=FontWeight.ExtraBold);if(sub!=null)Text(sub,fontSize=13.sp,color=Muted)};trailing?.invoke()}
}
@Composable private fun OpsCard(modifier:Modifier=Modifier, content:@Composable ColumnScope.()->Unit){
 Surface(modifier,shape=RoundedCornerShape(18.dp),color=Surface.copy(alpha=.96f),border=BorderStroke(1.dp,Color.White.copy(alpha=.065f))){Column(Modifier.padding(15.dp),content=content)}
}
@Composable private fun SectionTitle(text:String,onMore:(()->Unit)?=null){
 Row(Modifier.fillMaxWidth().padding(vertical=10.dp),verticalAlignment=Alignment.CenterVertically){Text(text,fontSize=17.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));if(onMore!=null)TextButton(onClick=onMore){Text("View all",color=Sky,fontSize=12.sp)}}
}
@Composable private fun StatusPill(label:String,color:Color=Gold){Surface(shape=RoundedCornerShape(40.dp),color=color.copy(alpha=.12f)){Text(label,Modifier.padding(horizontal=9.dp,vertical=5.dp),fontSize=10.sp,fontWeight=FontWeight.Bold,color=color)}}
@Composable private fun Metric(title:String,value:String,accent:Color,icon:ImageVector,modifier:Modifier=Modifier){
 OpsCard(modifier){Icon(icon,null,tint=accent,modifier=Modifier.size(19.dp));Spacer(Modifier.height(9.dp));Text(value,fontSize=25.sp,fontWeight=FontWeight.Black);Text(title,fontSize=11.sp,color=Muted)}
}
@Composable private fun EmptyState(title:String,detail:String,icon:ImageVector){
 Column(Modifier.fillMaxWidth().padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(icon,null,tint=Muted,modifier=Modifier.size(32.dp));Spacer(Modifier.height(12.dp));Text(title,fontWeight=FontWeight.Bold);Text(detail,fontSize=12.sp,color=Muted)}
}
@Composable private fun HomePage(vm:OpsViewModel,onNavigate:(String)->Unit){
 LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(horizontal=18.dp,vertical=17.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
   item {
     Header("Operations overview","Your projects, agents and daily execution")
     OpsCard(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF172B4E),Surface)))) {
       Row(verticalAlignment=Alignment.Top){Column(Modifier.weight(1f)){
        StatusPill(if(vm.sessionValid)"SECURE SESSION" else "LOCAL WORKSPACE",if(vm.sessionValid)Mint else Gold)
        Spacer(Modifier.height(12.dp));Text("One command center.\nEvery operation.",fontSize=23.sp,fontWeight=FontWeight.ExtraBold,lineHeight=28.sp)
        Spacer(Modifier.height(9.dp));Text("Native Android control for projects, workers, calendar and connected systems.",fontSize=12.sp,color=Muted)
       };Icon(Icons.Default.RocketLaunch,null,tint=Gold,modifier=Modifier.size(48.dp))}
       Spacer(Modifier.height(14.dp))
       Button(onClick={onNavigate("codex")},colors=ButtonDefaults.buttonColors(containerColor=Gold,contentColor=Bg),shape=RoundedCornerShape(10.dp)) {Icon(Icons.Default.AutoAwesome,null);Spacer(Modifier.width(8.dp));Text("Open Codex workspace",fontWeight=FontWeight.Bold)}
     }
   }
   item {Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){
      Metric("Active projects",vm.projects.count{it.status=="Active"}.toString(),Sky,Icons.Default.FolderOpen,Modifier.weight(1f))
      Metric("Due today",vm.todayDue().toString(),Gold,Icons.Default.TaskAlt,Modifier.weight(1f))
   }}
   item {Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){
      Metric("Registered workers",vm.workers.size.toString(),Mint,Icons.Default.SmartToy,Modifier.weight(1f))
      Metric("Connected services",vm.connected.size.toString(),Rose,Icons.Default.Hub,Modifier.weight(1f))
   }}
   item {SectionTitle("Quick actions")}
   item {Row(horizontalArrangement=Arrangement.spacedBy(9.dp)){
     QuickAction("Project",Icons.Default.AddCircle,Sky,Modifier.weight(1f)){onNavigate("projects")}
     QuickAction("Schedule",Icons.Default.CalendarMonth,Gold,Modifier.weight(1f)){onNavigate("calendar")}
     QuickAction("Worker",Icons.Default.SmartToy,Mint,Modifier.weight(1f)){onNavigate("workers")}
   }}
   item {SectionTitle("Priority tasks",onMore={onNavigate("projects")})}
   if(vm.tasks.none{!it.done}) item {OpsCard{EmptyState("No open tasks","Add a task to start tracking deliverables.",Icons.Default.CheckCircleOutline)}}
   else items(vm.tasks.filter{!it.done}.take(4),key={it.id}){ task -> TaskRow(task,vm) }
   item {SectionTitle("Connector readiness",onMore={onNavigate("connectors")})}
   item {OpsCard{Text("Services can be authorized individually through your secure gateway. No provider credentials are stored in the APK.",color=Muted,fontSize=12.sp);Spacer(Modifier.height(8.dp));Text("${connectionCatalog.size} connector slots · ${vm.connected.size} checked this session",color=Gold,fontWeight=FontWeight.Bold,fontSize=12.sp)}}
 }
}
@Composable private fun QuickAction(title:String,icon:ImageVector,tint:Color,modifier:Modifier,onClick:()->Unit){
 OpsCard(modifier.clickable(onClick=onClick)){Icon(icon,null,tint=tint);Spacer(Modifier.height(5.dp));Text(title,fontWeight=FontWeight.Bold,fontSize=12.sp)}
}

@Composable private fun TaskRow(t:OpsTask,vm:OpsViewModel){
 OpsCard(Modifier.fillMaxWidth()) { Row(verticalAlignment=Alignment.CenterVertically){Checkbox(checked=t.done,onCheckedChange={vm.toggleTask(t.id)},colors=CheckboxDefaults.colors(checkedColor=Mint));Column(Modifier.weight(1f)){Text(t.title,fontWeight=FontWeight.SemiBold,fontSize=14.sp,maxLines=2,overflow=TextOverflow.Ellipsis);Text("Due ${t.due} · ${t.priority}",fontSize=11.sp,color=Muted)};StatusPill(if(t.done)"DONE" else t.priority,if(t.done)Mint else if(t.priority=="Urgent")Rose else Gold)} }
}

@Composable private fun ChatPage(vm:OpsViewModel){
 val activity=LocalContext.current as ComponentActivity
 var input by remember{mutableStateOf("")}
 val canSend=input.isNotBlank() && !vm.busy
 Column(Modifier.fillMaxSize().padding(horizontal=16.dp)) {
   Header("Codex command","Your private AI operations conversation",trailing={IconButton(onClick={val i=Intent(Intent.ACTION_VIEW,android.net.Uri.parse("https://chatgpt.com/codex"));activity.startActivity(i)}){Icon(Icons.Default.OpenInNew,"Open official Codex",tint=Sky)}})
   if(!vm.sessionValid) OpsCard(Modifier.fillMaxWidth()){
      Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.LockOutline,null,tint=Gold);Spacer(Modifier.width(8.dp));Column(Modifier.weight(1f)){Text("Gateway sign-in required",fontWeight=FontWeight.Bold,fontSize=13.sp);Text("A real Codex connection needs an authorized gateway. You can draft messages locally until connected.",fontSize=11.sp,color=Muted)}}
      Spacer(Modifier.height(8.dp));TextButton(onClick={AuthFlow.launch(activity,vm)}){Text("Sign in to gateway",color=Gold)}
   }
   Spacer(Modifier.height(10.dp))
   LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(9.dp),contentPadding=PaddingValues(vertical=12.dp)){
     if(vm.chat.isEmpty()) item {EmptyState("Ready for your instructions","Draft commands now. Live answers require an authenticated Codex-compatible API.",Icons.Default.AutoAwesome)}
     items(vm.chat,key={it.at+it.content}){entry->Row(Modifier.fillMaxWidth(),horizontalArrangement=if(entry.role=="user")Arrangement.End else Arrangement.Start){
       Surface(color=if(entry.role=="user")Color(0xFF244265) else Surface,shape=RoundedCornerShape(16.dp),modifier=Modifier.fillMaxWidth(.88f)){Column(Modifier.padding(13.dp)){Text(if(entry.role=="user")"YOU" else "ASSISTANT",color=if(entry.role=="user")Sky else Gold,fontSize=10.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(4.dp));Text(entry.content,fontSize=13.sp,lineHeight=19.sp)}}
     }}
   }
   Row(Modifier.fillMaxWidth().padding(bottom=8.dp),verticalAlignment=Alignment.Bottom){
     OutlinedTextField(input,{input=it},Modifier.weight(1f),placeholder={Text("Message your operations agent...",fontSize=12.sp)},shape=RoundedCornerShape(18.dp),maxLines=4)
     Spacer(Modifier.width(7.dp))
     FilledIconButton(onClick={val msg=input.trim();input="";vm.sendLocalMessage(msg)
       if(vm.sessionValid){vm.busy=true;thread {
          val reply=try{OpsApi(vm).ask(msg)}catch(e:Exception){"Gateway error: ${e.message ?: "Unavailable"}"}
          activity.runOnUiThread{vm.addResponse(reply);vm.busy=false}
       }}else vm.toast="Message saved locally; connect Codex to receive replies"
     },enabled=canSend,colors=IconButtonDefaults.filledIconButtonColors(containerColor=Gold,contentColor=Bg),modifier=Modifier.size(48.dp)) {if(vm.busy)CircularProgressIndicator(Modifier.size(19.dp),strokeWidth=2.dp,color=Bg) else Icon(Icons.Default.ArrowUpward,"Send")}
   }
 }
}

@Composable private fun ProjectsPage(vm:OpsViewModel){
 var segment by remember {mutableStateOf("tasks")}
 var newProject by remember {mutableStateOf(false)}
 var newTask by remember {mutableStateOf(false)}
 Column(Modifier.fillMaxSize().padding(horizontal=18.dp)){
   Header("Projects & tasks","A single execution pipeline",trailing={FilledIconButton(onClick={if(segment=="projects")newProject=true else newTask=true},colors=IconButtonDefaults.filledIconButtonColors(containerColor=Gold,contentColor=Bg)){Icon(Icons.Default.Add,"Add")}})
   SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
    listOf("tasks" to "Tasks","projects" to "Projects").forEachIndexed { index,p ->
      SegmentedButton(selected=segment==p.first,onClick={segment=p.first},shape=SegmentedButtonDefaults.itemShape(index,2),label={Text(p.second)})
    }
   }
   Spacer(Modifier.height(16.dp))
   if(segment=="projects") {
     if(vm.projects.isEmpty())EmptyState("No projects yet","Create your first ongoing project.",Icons.Default.Folder)
     else LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=20.dp)){
       items(vm.projects,key={it.id}){ p->OpsCard(Modifier.fillMaxWidth()){
         Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(37.dp).clip(RoundedCornerShape(12.dp)).background(Sky.copy(alpha=.14f)),contentAlignment=Alignment.Center){Icon(Icons.Default.FolderOpen,null,tint=Sky)};Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Bold);Text("Since ${p.created}",fontSize=11.sp,color=Muted)};StatusPill(p.status,if(p.status=="Active")Mint else Muted)}
         if(p.details.isNotBlank()){Spacer(Modifier.height(8.dp));Text(p.details,fontSize=12.sp,color=Muted)}
         Spacer(Modifier.height(7.dp));Row {Text("${vm.tasks.count{it.projectId==p.id}} tasks",fontSize=12.sp,color=Sky,modifier=Modifier.weight(1f));TextButton(onClick={vm.updateProject(p.id,if(p.status=="Active")"Completed" else "Active")}){Text(if(p.status=="Active")"Mark complete" else "Reopen",fontSize=11.sp)}}
       }}
     }
   } else {
     if(vm.tasks.isEmpty())EmptyState("No tasks yet","Add a task, deadline and priority.",Icons.Default.Task)
     else LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp),contentPadding=PaddingValues(bottom=24.dp)){
       items(vm.tasks.sortedWith(compareBy<OpsTask>{it.done}.thenBy{it.due}),key={it.id}){ TaskRow(it,vm) }
     }
   }
 }
 if(newProject)ProjectDialog(onDismiss={newProject=false},onSave={n,d->vm.addProject(n,d);newProject=false})
 if(newTask)TaskDialog(vm,onDismiss={newTask=false},onSave={n,p,d,pr->vm.addTask(n,p,d,pr);newTask=false})
}
@Composable private fun ProjectDialog(onDismiss:()->Unit,onSave:(String,String)->Unit){
 var name by remember{mutableStateOf("")};var details by remember{mutableStateOf("")}
 AlertDialog(onDismissRequest=onDismiss,title={Text("New project")},text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
   OutlinedTextField(name,{name=it},label={Text("Project name")},singleLine=true)
   OutlinedTextField(details,{details=it},label={Text("Scope / description")},minLines=2,maxLines=4)
 }},confirmButton={TextButton(onClick={onSave(name,details)},enabled=name.isNotBlank()){Text("Create")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}
@Composable private fun TaskDialog(vm:OpsViewModel,onDismiss:()->Unit,onSave:(String,String,String,String)->Unit){
 var title by remember{mutableStateOf("")};var date by remember{mutableStateOf(LocalDate.now().toString())};var priority by remember{mutableStateOf("Normal")};var project by remember{mutableStateOf("")}
 var projectsOpen by remember{mutableStateOf(false)}
 AlertDialog(onDismissRequest=onDismiss,title={Text("New task")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
   OutlinedTextField(title,{title=it},label={Text("Task title")},singleLine=true)
   OutlinedTextField(date,{date=it},label={Text("Due date YYYY-MM-DD")},singleLine=true)
   ExposedDropdownMenuBox(expanded=projectsOpen,onExpandedChange={projectsOpen=it}){
     OutlinedTextField(vm.projects.find{it.id==project}?.name ?: "Unassigned",onValueChange={},readOnly=true,label={Text("Project")},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded=projectsOpen)},modifier=Modifier.menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable))
     ExposedDropdownMenu(expanded=projectsOpen,onDismissRequest={projectsOpen=false}) {
       DropdownMenuItem(text={Text("Unassigned")},onClick={project="";projectsOpen=false})
       vm.projects.forEach{p->DropdownMenuItem(text={Text(p.name)},onClick={project=p.id;projectsOpen=false})}
     }
   }
   Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){listOf("Normal","High","Urgent").forEach{pr->FilterChip(selected=priority==pr,onClick={priority=pr},label={Text(pr,fontSize=11.sp)})}}
 }},confirmButton={TextButton(onClick={onSave(title,project,date,priority)},enabled=title.isNotBlank() && runCatching{LocalDate.parse(date)}.isSuccess){Text("Add task")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}

@Composable private fun CalendarPage(vm:OpsViewModel){
 var shown by remember{mutableStateOf(YearMonth.now())};var selected by remember{mutableStateOf(LocalDate.now())};var add by remember{mutableStateOf(false)}
 Column(Modifier.fillMaxSize().padding(horizontal=18.dp)) {
   Header("Operations calendar","Appointments, deadlines and milestones",trailing={FilledIconButton(onClick={add=true},colors=IconButtonDefaults.filledIconButtonColors(containerColor=Gold,contentColor=Bg)){Icon(Icons.Default.Add,"Add event")}})
   OpsCard(Modifier.fillMaxWidth()) {
     Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick={shown=shown.minusMonths(1)}){Icon(Icons.Default.ChevronLeft,"Previous month")};Text(shown.format(DateTimeFormatter.ofPattern("MMMM yyyy",Locale.ENGLISH)),Modifier.weight(1f),fontSize=18.sp,fontWeight=FontWeight.Bold);IconButton(onClick={shown=shown.plusMonths(1)}){Icon(Icons.Default.ChevronRight,"Next month")}}
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly){listOf("M","T","W","T","F","S","S").forEach{Text(it,color=Muted,fontSize=11.sp,modifier=Modifier.weight(1f),textAlign=androidx.compose.ui.text.style.TextAlign.Center)}}
     Spacer(Modifier.height(8.dp))
     val offset=shown.atDay(1).dayOfWeek.value-1
     val days=shown.lengthOfMonth()
     repeat(6){rowIndex-> Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly){
       repeat(7){ colIndex -> val d=rowIndex*7+colIndex-offset+1
         if(d in 1..days){val day=shown.atDay(d);val sel=day==selected;val has=vm.meetings.any{it.date==day.toString()} || vm.tasks.any{it.due==day.toString() && !it.done}
           Column(Modifier.weight(1f).height(50.dp).clip(RoundedCornerShape(9.dp)).background(if(sel)Surface2 else Color.Transparent).clickable{selected=day},horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text(d.toString(),color=if(sel)Gold else if(day==LocalDate.now())Sky else Color.White,fontWeight=if(sel)FontWeight.Bold else FontWeight.Normal);if(has)Box(Modifier.padding(top=4.dp).size(4.dp).clip(CircleShape).background(Gold))}
         }else Spacer(Modifier.weight(1f).height(50.dp))
       }
     } }
   }
   Spacer(Modifier.height(18.dp))
   SectionTitle(selected.format(DateTimeFormatter.ofPattern("EEEE, MMM d",Locale.ENGLISH)))
   val d=selected.toString();val events=vm.meetings.filter{it.date==d};val deadlines=vm.tasks.filter{it.due==d && !it.done}
   if(events.isEmpty()&&deadlines.isEmpty())EmptyState("Clear schedule","No local events or pending tasks for this day.",Icons.Default.EventAvailable)
   else LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp)){
     items(events,key={it.id}) { ev->OpsCard {Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Event,null,tint=Sky);Spacer(Modifier.width(10.dp));Column{Text(ev.title,fontWeight=FontWeight.Bold);if(ev.notes.isNotBlank())Text(ev.notes,fontSize=12.sp,color=Muted)}}} }
     items(deadlines,key={it.id}){TaskRow(it,vm)}
   }
 }
 if(add)EventDialog(defaultDate=selected.toString(),onDismiss={add=false},onSave={n,d,notes->vm.addMeeting(n,d,notes);add=false})
}
@Composable private fun EventDialog(defaultDate:String,onDismiss:()->Unit,onSave:(String,String,String)->Unit){
 var name by remember{mutableStateOf("")};var date by remember{mutableStateOf(defaultDate)};var notes by remember{mutableStateOf("")}
 AlertDialog(onDismissRequest=onDismiss,title={Text("Calendar event")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
   OutlinedTextField(name,{name=it},label={Text("Event")},singleLine=true)
   OutlinedTextField(date,{date=it},label={Text("Date YYYY-MM-DD")},singleLine=true)
   OutlinedTextField(notes,{notes=it},label={Text("Notes")},maxLines=3)
 }},confirmButton={TextButton(onClick={onSave(name,date,notes)},enabled=name.isNotBlank()&&runCatching{LocalDate.parse(date)}.isSuccess){Text("Save")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}

@Composable private fun WorkersPage(vm:OpsViewModel){
 val activity=LocalContext.current as ComponentActivity
 var add by remember{mutableStateOf(false)}
 Column(Modifier.fillMaxSize().padding(horizontal=18.dp)) {
   Header("Worker command", "Dedicated agent and automation control",trailing={FilledIconButton(onClick={add=true},colors=IconButtonDefaults.filledIconButtonColors(containerColor=Gold,contentColor=Bg)){Icon(Icons.Default.Add,"Add worker")}})
   OpsCard(Modifier.fillMaxWidth()) {
      Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Security,null,tint=Gold);Spacer(Modifier.width(10.dp));Column{Text("Verified status only",fontWeight=FontWeight.Bold);Text("Worker health is never shown as active unless the authorized gateway confirms it.",fontSize=11.sp,color=Muted)}}
   }
   Spacer(Modifier.height(14.dp))
   if(vm.workers.isEmpty())EmptyState("No workers registered","Add workers and connect a secure gateway to check health.",Icons.Default.SmartToy)
   else LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=24.dp)){
     items(vm.workers,key={it.id}) {w->OpsCard(Modifier.fillMaxWidth()){
       Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(41.dp).clip(RoundedCornerShape(12.dp)).background(Sky.copy(alpha=.13f)),contentAlignment=Alignment.Center){Icon(Icons.Default.SmartToy,null,tint=Sky)};Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(w.name,fontWeight=FontWeight.Bold);Text(w.role,color=Muted,fontSize=11.sp)};StatusPill(w.lastStatus,if(w.lastStatus.equals("online",true))Mint else Gold)}
       if(w.endpoint.isNotBlank()){Spacer(Modifier.height(8.dp));Text("Endpoint registered (server-side)",fontSize=11.sp,color=Muted)}
       Spacer(Modifier.height(6.dp))
       OutlinedButton(onClick={
          if(!vm.sessionValid){vm.toast="Sign in to a secure gateway before checking a worker";return@OutlinedButton}
          vm.updateWorker(w.id,"Checking")
          thread {val status=try{OpsApi(vm).status(w)}catch(_:Exception){"Unavailable"};activity.runOnUiThread{vm.updateWorker(w.id,status)}}
       },modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Refresh,null,Modifier.size(16.dp));Spacer(Modifier.width(5.dp));Text("Check live status")}
     }}
   }
 }
 if(add)WorkerDialog(onDismiss={add=false},onSave={n,r,e->vm.addWorker(n,r,e);add=false})
}
@Composable private fun WorkerDialog(onDismiss:()->Unit,onSave:(String,String,String)->Unit){
 var name by remember{mutableStateOf("")};var role by remember{mutableStateOf("")};var endpoint by remember{mutableStateOf("")}
 AlertDialog(onDismissRequest=onDismiss,title={Text("Register worker")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
   OutlinedTextField(name,{name=it},label={Text("Worker name")},singleLine=true)
   OutlinedTextField(role,{role=it},label={Text("Role / assignment")},singleLine=true)
   OutlinedTextField(endpoint,{endpoint=it},label={Text("Worker endpoint ID or label")},singleLine=true)
   Text("Worker secrets and execution endpoints must be registered on the gateway, not stored on Android.",fontSize=11.sp,color=Muted)
 }},confirmButton={TextButton(onClick={onSave(name,role,endpoint)},enabled=name.isNotBlank()){Text("Add worker")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}

@Composable private fun ConnectorsPage(vm:OpsViewModel){
 val activity=LocalContext.current as ComponentActivity
 var filter by remember{mutableStateOf("All")}
 val groups=listOf("All","AI Workspace","Google","Infrastructure","Engineering","Database","Meta","Files")
 Column(Modifier.fillMaxSize()){
   Column(Modifier.padding(horizontal=18.dp)){
     Header("Connectors","Manage approved accounts and services")
     OpsCard(Modifier.fillMaxWidth()){
       Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.VerifiedUser,null,tint=Gold);Spacer(Modifier.width(10.dp));Column {Text("Secure provider authorization",fontWeight=FontWeight.Bold,fontSize=13.sp);Text("OAuth through your gateway. No pasted passwords or database connection strings.",fontSize=11.sp,color=Muted)}}
     }
   }
   Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal=18.dp,vertical=10.dp),horizontalArrangement=Arrangement.spacedBy(7.dp)){
      groups.forEach{g->FilterChip(selected=filter==g,onClick={filter=g},label={Text(g,fontSize=11.sp)})}
   }
   LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(horizontal=18.dp,vertical=7.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
     items(connectionCatalog.filter{filter=="All"||it.category==filter},key={it.id}){ provider ->
       OpsCard(Modifier.fillMaxWidth()) {
         Row(verticalAlignment=Alignment.CenterVertically){
           Box(Modifier.size(45.dp).clip(RoundedCornerShape(12.dp)).background(if(provider.category=="Database")Gold.copy(alpha=.13f) else Sky.copy(alpha=.12f)),contentAlignment=Alignment.Center){Icon(when(provider.category){"Database"->Icons.Default.Storage;"AI Workspace"->Icons.Default.AutoAwesome;"Meta"->Icons.Default.Public;"Google"->Icons.Default.AccountCircle;else->Icons.Default.Hub},null,tint=if(provider.category=="Database")Gold else Sky)}
           Spacer(Modifier.width(11.dp))
           Column(Modifier.weight(1f)){Text(provider.title,fontWeight=FontWeight.Bold,fontSize=14.sp);Text(provider.category,fontSize=10.sp,color=Muted)}
           StatusPill(if(provider.id in vm.connected)"VERIFIED" else "NOT CONNECTED",if(provider.id in vm.connected)Mint else Muted)
         }
         Spacer(Modifier.height(8.dp));Text(provider.sub,fontSize=11.sp,color=Muted)
         Spacer(Modifier.height(8.dp))
         OutlinedButton(onClick={
           if(provider.auth=="server"){vm.toast="Configure ${provider.title} in the secure server secret store; never enter database secrets in the app"}
           else if(!vm.sessionValid && provider.id!="codex") {vm.toast="Sign in to your operations gateway first"}
           else if(provider.id=="codex") {AuthFlow.launch(activity,vm,"chatgpt")}
           else {
             if(vm.gatewayUrl.isBlank()) {vm.toast="Configure your HTTPS gateway in Settings first"}
             else {thread{
               val status=runCatching{OpsApi(vm).authorizeConnector(provider.id)}.getOrDefault(false)
               activity.runOnUiThread {
                 if(status){vm.markConnected(provider.id);vm.toast="${provider.title}: gateway reachable; authorization status must be confirmed server-side"}
                 else AuthFlow.launch(activity,vm,provider.id)
               }
             }}
           }
         },modifier=Modifier.fillMaxWidth()){
            Icon(if(provider.id in vm.connected)Icons.Default.Refresh else Icons.Default.Link,null,Modifier.size(17.dp))
            Spacer(Modifier.width(7.dp));Text(if(provider.id in vm.connected)"Recheck connection" else if(provider.auth=="server")"Server configuration" else "Connect ${provider.title}",fontSize=12.sp)
         }
       }
     }
   }
 }
}

@Composable private fun SettingsPage(vm:OpsViewModel,onBack:()->Unit){
 val activity=LocalContext.current as ComponentActivity
 var url by remember{mutableStateOf(vm.gatewayUrl)}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=18.dp)){
   Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Back",tint=Gold)};Spacer(Modifier.width(6.dp));Text("Settings & security",fontSize=24.sp,fontWeight=FontWeight.ExtraBold)}
   Spacer(Modifier.height(15.dp))
   OpsCard(Modifier.fillMaxWidth()){
     Text("Workspace identity",fontWeight=FontWeight.Bold,fontSize=16.sp)
     Spacer(Modifier.height(10.dp))
     StatusPill(if(vm.sessionValid)"ENCRYPTED SESSION" else "NO ACCOUNT LINKED",if(vm.sessionValid)Mint else Gold)
     Spacer(Modifier.height(9.dp))
     Text("Sign-in is delegated to your own OAuth-enabled operations gateway. To use your ChatGPT account, the app must be enrolled in the official Sign in with ChatGPT program.",fontSize=12.sp,color=Muted)
     Spacer(Modifier.height(12.dp))
     Button(onClick={if(vm.sessionValid)vm.signOut() else AuthFlow.launch(activity,vm)},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Gold,contentColor=Bg)){
       Icon(if(vm.sessionValid)Icons.Default.Logout else Icons.Default.Login,null)
       Spacer(Modifier.width(8.dp));Text(if(vm.sessionValid)"Sign out" else "Sign in securely")
     }
   }
   Spacer(Modifier.height(14.dp))
   OpsCard(Modifier.fillMaxWidth()){
     Text("Operations gateway",fontWeight=FontWeight.Bold,fontSize=16.sp)
     Text("Enter an authorized HTTPS backend with /v1 endpoints. Your existing domains are not assumed to support this API.",fontSize=11.sp,color=Muted)
     Spacer(Modifier.height(7.dp))
     OutlinedTextField(value=url,onValueChange={url=it},label={Text("https://ops.example.com")},singleLine=true,modifier=Modifier.fillMaxWidth(),keyboardOptions=KeyboardOptions(autoCorrectEnabled=false))
     Spacer(Modifier.height(7.dp))
     OutlinedButton(onClick={vm.setGateway(url)},modifier=Modifier.fillMaxWidth()){Text("Save gateway URL")}
   }
   Spacer(Modifier.height(14.dp))
   OpsCard(Modifier.fillMaxWidth()){
     Text("Android application",fontWeight=FontWeight.Bold,fontSize=16.sp)
     Spacer(Modifier.height(9.dp))
     listOf("Product" to "KBT Operations", "Application ID" to "digital.kbt.operations", "Native UI" to "Jetpack Compose", "Target Android" to "17 · API 37", "Backup" to "Disabled", "Network" to "HTTPS required").forEach{(a,b)->Row(Modifier.fillMaxWidth().padding(vertical=5.dp)){Text(a,Modifier.weight(1f),fontSize=12.sp,color=Muted);Text(b,fontWeight=FontWeight.SemiBold,fontSize=12.sp)}}
   }
   Spacer(Modifier.height(20.dp))
 }
}

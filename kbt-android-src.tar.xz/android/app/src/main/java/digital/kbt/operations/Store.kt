package digital.kbt.operations

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import java.time.LocalDate

class OperationsApp: Application()
class OpsViewModel(app: Application): AndroidViewModel(app) {
    private val preferences = app.getSharedPreferences("kbt_local_workspace_v1", Context.MODE_PRIVATE)
    val projects = mutableStateListOf<Project>().apply { addAll(parseRecords(preferences.getString("projects", "[]"), Project.Companion::from)) }
    val tasks = mutableStateListOf<OpsTask>().apply { addAll(parseRecords(preferences.getString("tasks", "[]"), OpsTask.Companion::from)) }
    val workers = mutableStateListOf<Worker>().apply { addAll(parseRecords(preferences.getString("workers", "[]"), Worker.Companion::from)) }
    val meetings = mutableStateListOf<Meeting>().apply { addAll(parseRecords(preferences.getString("meetings", "[]"), Meeting.Companion::from)) }
    val chat = mutableStateListOf<ChatEntry>().apply { addAll(parseRecords(preferences.getString("chat", "[]"), ChatEntry.Companion::from)) }
    var gatewayUrl by mutableStateOf(preferences.getString("gateway", "") ?: "")
        private set
    var toast by mutableStateOf("")
    var busy by mutableStateOf(false)
    var sessionValid by mutableStateOf(Vault(app).readToken() != null)
    var connected by mutableStateOf(setOf<String>())
    val vault = Vault(app)

    fun addProject(name: String, details: String) { if(name.isBlank()) return; projects.add(Project(name=name.trim(), details=details.trim())); save() }
    fun updateProject(id:String,status:String) { val i=projects.indexOfFirst{it.id==id}; if(i>=0){projects[i]=projects[i].copy(status=status);save()} }
    fun addTask(title:String,projectId:String,due:String,priority:String) { if(title.isBlank()) return; tasks.add(OpsTask(title=title.trim(),projectId=projectId,due=due,priority=priority));save() }
    fun toggleTask(id:String) { val i=tasks.indexOfFirst{it.id==id};if(i>=0){tasks[i]=tasks[i].copy(done=!tasks[i].done);save()} }
    fun addWorker(name:String,role:String,endpoint:String) { if(name.isBlank())return; workers.add(Worker(name=name.trim(),role=role.trim(), endpoint=endpoint.trim()));save() }
    fun updateWorker(id:String,status:String) { val i=workers.indexOfFirst{it.id==id};if(i>=0){workers[i]=workers[i].copy(lastStatus=status);save()} }
    fun addMeeting(title:String,date:String,notes:String) { if(title.isBlank())return; meetings.add(Meeting(title=title.trim(),date=date,notes=notes));save() }
    fun sendLocalMessage(content:String) { if(content.isBlank())return; chat.add(ChatEntry("user",content));save() }
    fun addResponse(content:String) { chat.add(ChatEntry("assistant",content));save() }
    fun setGateway(url:String) {
        val u=url.trim().trimEnd('/')
        if(u.isNotEmpty() && (!u.startsWith("https://") || u.contains("@"))) { toast="Use a trusted HTTPS gateway URL";return }
        gatewayUrl=u
        preferences.edit().putString("gateway",u).apply()
        toast="Gateway address saved on device"
    }
    fun markConnected(id:String) { connected=connected+id }
    fun signOut() {vault.clear();sessionValid=false;connected=emptySet();toast="Signed out"}
    fun save() {
        preferences.edit()
            .putString("projects",serializeRecords(projects,Project::toJson))
            .putString("tasks",serializeRecords(tasks,OpsTask::toJson))
            .putString("workers",serializeRecords(workers,Worker::toJson))
            .putString("meetings",serializeRecords(meetings,Meeting::toJson))
            .putString("chat",serializeRecords(chat,ChatEntry::toJson))
            .apply()
    }
    fun todayDue() = tasks.count{!it.done && it.due==LocalDate.now().toString()}
}

# KBT Operations backend / connector contract

## Trust model

- Android app is a public client. Use OAuth 2.1 authorization code + PKCE (`S256`), state verification and browser/Custom Tabs. Do not use WebView for OAuth.
- The authorize endpoint must require a real user identity and consent, issue short-lived single-use codes, validate `redirect_uri` and PKCE, and bind the authorized provider/account to the signed-in user.
- The token exchange must return an operations session token with scope and expiry. Do not return provider refresh tokens to Android.
- The app currently stores the issued access token in Android KeyStore-backed AES/GCM locally; production must implement expiration and refresh/session revocation policies, plus Android App Links to prevent custom-scheme collision.
- Provider OAuth access/refresh tokens are encrypted on backend, never included in APK, git history or local workspace.
- Verify every worker/task command with least-privilege RBAC and audit logging. Require approval for deploy, delete, payment, or irreversible actions.
- Connectors: Gmail/GDrive/GCalendar (Google OAuth app), GitHub OAuth App or GitHub App installation, Cloudflare OAuth or scoped provider token on backend, Vercel OAuth integration, Dropbox OAuth, Meta Business Login for Facebook/Instagram, Neon API through server, MongoDB Atlas API through server.
- Commercial Sign in with ChatGPT requires registered client/app approval. Codex Cloud is **not** guaranteed accessible using arbitrary third-party OAuth tokens. Avoid unofficial use of cookie/session token extraction.

## Suggested backend tables
`users`, `sessions`, `oauth_accounts`, `projects`, `tasks`, `calendar_events`, `workers`, `worker_runs`, `run_logs`, `approvals`, `audit_events`, `messages`, `connector_health`.

## API surface
`/v1/auth/authorize`, `/v1/auth/token`, `/v1/auth/logout`, `/v1/me`, `/v1/codex/messages`, `/v1/projects`, `/v1/tasks`, `/v1/calendar/events`, `/v1/workers`, `/v1/workers/:id/status`, `/v1/workers/:id/commands`, `/v1/connectors`, `/v1/connectors/:provider/status`, `/v1/connectors/:provider/connect`, `/v1/connectors/:provider/disconnect`.

Use provider-owned official SDK/APIs. Treat unconfigured services as `Not connected`; never report fictitious success.

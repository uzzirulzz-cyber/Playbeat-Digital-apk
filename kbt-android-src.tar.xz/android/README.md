# KBT Operations — native Android enterprise console

A **native Android application**, not a WebView / website wrapper. Kotlin, Jetpack Compose, Material 3 and native Android KeyStore. Application ID: `digital.kbt.operations`.

## Implemented
- Android 17 / API 37 target, Android 8+ minimum, adaptive portrait/landscape interface and themed launcher icon.
- Native dashboard: live-only-when-confirmed status cues, key metrics, task previews, quick actions.
- Projects: create, persist, mark complete/reopen. Tasks: create, assign to project, due dates, priorities and completion.
- Calendar: month switcher, task deadlines, local events with date validation.
- Workers: registration, roles, state display, server-authenticated check (does not simulate online workers).
- Codex conversation UI: local drafts/history, backend responses through a secure `/v1/codex/messages` endpoint, official Codex link.
- Connectors: ChatGPT/Codex, Gmail, Google Calendar, Google Drive, Dropbox, GitHub, Vercel, Cloudflare, Neon, MongoDB, Facebook Pages and Instagram Business.
- Settings: secure HTTPS gateway entry, browser-based OAuth PKCE, AndroidKeyStore encrypted session, logout.
- Explicit unconnected/error states; app never invents cloud execution, connected statuses, or workers.
- GitHub Actions workflow building and verifying a **real `KBT-Operations.apk`**.

## Critical integration boundary
This repository does **not** create a fake ChatGPT login. To support `Sign in with ChatGPT` in a proprietary commercial Android app, an approved application registration/client ID is required by OpenAI. The user-facing login button uses your backend's OAuth authorize endpoint. ChatGPT sign-in does not automatically grant access to ChatGPT conversations or Codex Cloud work sessions. The backend must implement each authorized connector and Codex-compatible API. Provider secrets and direct database URLs belong **only on the server**.

The app does **not** claim these providers are connected merely because their buttons exist. OAuth/database controls are prepared, but backend registration, app approval and production token exchange must be configured before live use.

## Local backend contract
See `docs/GATEWAY_API.md`. Gateway must be HTTPS. App expects:
- `GET /v1/auth/authorize?provider=...&client_id=kbt-android&redirect_uri=kbtops://auth/callback&code_challenge=...&code_challenge_method=S256&state=...`
- `POST /v1/auth/token` with `authorization_code` and `code_verifier`.
- `POST /v1/codex/messages` authenticated with Bearer; JSON `{"message":"..."}` returns `{"reply":"..."}`.
- `GET /v1/workers/{id}/status` authenticated, returns `{ "status": "Online|Offline|Busy|Unavailable" }`.
- `GET /v1/connectors/{id}/status` authenticated; **HTTP 200 alone only means the endpoint responds**, not proof of an authorized connection. Implement verified provider status on the server.

## Build
Requires Android Studio with Android API 37, Java 21+, Gradle 9.7.1 and Android Gradle Plugin 9.3.1. From `android/` run `gradle :app:assembleDebug`; output `app/build/outputs/apk/debug/app-debug.apk`. CI copies this to `KBT-Operations.apk` and uploads it as a GitHub Actions artifact. For Play Store/Samsung Galaxy Store create a release keystore, release build, privacy/data safety declarations, app screenshots, and real provider authorization. The debug APK is for sideload testing only, **not a store-ready release**.
